#include <iostream>
using namespace std;


int sum_divisors(int x);


int main () {
    int x;
    while (cin >> x) cout << sum_divisors(x) << endl;
    return 0;
}
