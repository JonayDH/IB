#include <iostream>
using namespace std;


int absolute(int n);


int main() {
    int n;
    cin >> n;
    cout << absolute(n) << endl;
    return 0;
}
