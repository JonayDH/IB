#include <iostream>
using namespace std;


void print(int s, char c, int n);


int main() {
  int s, n;
  char c;
  while (cin >> s >> c >> n) print(s, c, n);
  return 0;
}
