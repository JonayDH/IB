#include <iostream>
using namespace std;


int double_factorial(int n);


int main() {
  int x;
  while (cin >> x) cout << double_factorial(x) << endl;
  return 0;
}
